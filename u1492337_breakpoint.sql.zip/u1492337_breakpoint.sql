-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2021 at 06:46 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u1492337_breakpoint`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `roles` varchar(10) NOT NULL,
  `login_at` varchar(128) DEFAULT NULL,
  `logout_at` varchar(128) DEFAULT NULL,
  `last_activity` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `roles`, `login_at`, `logout_at`, `last_activity`) VALUES
(1, 'daffakurnia11', 'dev', '23:44:48 01-06-2021', '23:44:40 01-06-2021', 'Update Shortenlink BootstrapNew'),
(2, 'kholid_al_fauzi', 'owner', '20:12:03 01-06-2021', '20:14:22 01-06-2021', NULL),
(3, 'annisaseptyana', 'designer', NULL, NULL, NULL),
(4, 'arinirumapar__', 'designer', NULL, NULL, NULL),
(5, 'a.fridua', 'creative', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `id` int(11) NOT NULL,
  `package` varchar(128) NOT NULL,
  `page` varchar(56) NOT NULL,
  `maintenance` varchar(56) NOT NULL,
  `domain` varchar(56) NOT NULL,
  `hosting` int(1) NOT NULL,
  `has_ssl` int(1) NOT NULL,
  `specials` text NOT NULL,
  `price` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`id`, `package`, `page`, `maintenance`, `domain`, `hosting`, `has_ssl`, `specials`, `price`) VALUES
(1, 'Landing Page', '1', '2 Minggu', '-', 0, 0, 'Static', '400k / Proyek'),
(2, 'Landing Page+', '1', '2 Minggu', 'Free Domain', 1, 0, 'Static', '950k / Tahun'),
(3, 'Small Business', '5', '2 Minggu', 'Free Domain', 1, 0, 'Static', '1450k / Tahun'),
(4, 'Medium Business', '5', '1 Bulan', 'Free Domain', 1, 1, 'Shorten Link', '1850k / Tahun'),
(5, 'Professional Business', '8', '1 Bulan', 'Free Domain', 1, 1, 'Admin Access, Data Management, Content Management System (CMS)', '2350k / Tahun'),
(6, 'Webinar Website', '5', '2 Minggu', 'Free Domain', 1, 1, 'Registration Form, Admin Access, Data Management, Email Verification', '2600k / Tahun'),
(7, 'Event Website', '10', '1 Bulan', 'Free Domain', 1, 1, 'Registration Form, Admin Access, Data Management, Content Management System (CMS), Email Verification, Shorten Link', '3600k / Tahun'),
(8, 'Mini Classroom', 'Unlimited', '2 Bulan', 'Free Domain', 1, 1, 'Registration Form, User-role Access, Data Management, Data Report, Present Code System, Scoring System, Files Management System, Schedule Management System', '4550k / Tahun'),
(9, 'E-Commerce Website', 'Unlimited', '2 Bulan', 'Free Domain', 1, 1, 'Admin Access, Data Management, Data Report, Content Management System (CMS), Shopping Cart System, Shipping Cost Estimation, Invoice Tracking System, Referral Code System', '5550k / Tahun'),
(10, 'Custom Website', 'Unlimited', '1 Bulan', '-', 0, 0, 'Static', '325k / Page');

-- --------------------------------------------------------

--
-- Table structure for table `shorten_link`
--

CREATE TABLE `shorten_link` (
  `id` int(11) NOT NULL,
  `name` varchar(56) NOT NULL,
  `original` varchar(256) NOT NULL,
  `shorten` varchar(128) NOT NULL,
  `created_at` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shorten_link`
--
ALTER TABLE `shorten_link`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `shorten_link`
--
ALTER TABLE `shorten_link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
